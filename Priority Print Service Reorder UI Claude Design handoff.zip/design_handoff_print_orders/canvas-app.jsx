/* Canvas wiring */

const { DesignCanvas, DCSection, DCArtboard } = window;

/* tiny wrapper that toggles mobile class */
const Frame = ({ mobile = false, children }) => (
  <div className={mobile ? "is-mobile" : ""} style={{ width: "100%", height: "100%", overflow: "hidden", display: "flex", flexDirection: "column" }}>
    {children}
  </div>
);

/* For dashboard / lookup, the artboard scrolls vertically (full page mocks). */
const ScrollFrame = ({ mobile = false, children }) => (
  <div className={mobile ? "is-mobile" : ""} style={{ width: "100%", height: "100%", overflowY: "auto", display: "flex", flexDirection: "column" }}>
    {children}
  </div>
);

const App = () => (
  <DesignCanvas
    title="Priority Print — Print Orders & Guest Lookup"
    subtitle="Logged-in dashboard, guest lookup, and the shared order-card component. Light CMYK accent treatment."
  >
    <DCSection id="component" title="01 · Order Card · all states">
      <DCArtboard id="oc-standard" label="Standard (PPS-era)" width={760} height={280}>
        <div className="pps" style={{ background: "var(--bg)", padding: 20 }}>
          <OrderCard />
        </div>
      </DCArtboard>

      <DCArtboard id="oc-legacy" label="Legacy (no thumbnail)" width={760} height={260}>
        <div className="pps" style={{ background: "var(--bg)", padding: 20 }}>
          <OrderCard
            variant="legacy"
            product="Perfect-Bound Catalog"
            orderNo="0941"
            date="Sep 03, 2024"
            status={{ label: "Delivered", kind: "delivered" }}
            eta=""
            specs={"8.5 × 11 · 64 pp · 250 sets · 4/4 · perfect bound · 80# gloss"}
          />
        </div>
      </DCArtboard>

      <DCArtboard id="oc-cancelled" label="Cancelled / refunded" width={760} height={280}>
        <div className="pps" style={{ background: "var(--bg)", padding: 20 }}>
          <OrderCard
            variant="cancelled"
            product="Saddle-Stitched Booklet"
            orderNo="2076"
            date="Apr 11, 2026"
            status={{ label: "Refunded", kind: "refunded" }}
            eta=""
            specs={"6 × 9 in · 50 sets · 16 pp · 4/4 color, 80# matte text"}
          />
        </div>
      </DCArtboard>

      <DCArtboard id="oc-hover" label="Reorder · hover" width={760} height={280}>
        <div className="pps" style={{ background: "var(--bg)", padding: 20 }}>
          <OrderCard variant="hover-demo" />
        </div>
      </DCArtboard>

      <DCArtboard id="oc-focus" label="Reorder · keyboard focus" width={760} height={280}>
        <div className="pps" style={{ background: "var(--bg)", padding: 20 }}>
          <OrderCard variant="focus-demo" />
        </div>
      </DCArtboard>
    </DCSection>

    <DCSection id="dashboard" title="02 · Print Orders dashboard (logged in)">
      <DCArtboard id="dash-many-d" label="Desktop · 4 items" width={1280} height={1640}>
        <ScrollFrame><Dashboard count="many" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="dash-one-d" label="Desktop · 1 item" width={1280} height={780}>
        <ScrollFrame><Dashboard count="one" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="dash-empty-d" label="Desktop · empty" width={1280} height={520}>
        <ScrollFrame><Dashboard count="empty" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="dash-many-m" label="Mobile · 4 items" width={390} height={1700}>
        <ScrollFrame mobile><Dashboard count="many" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="dash-empty-m" label="Mobile · empty" width={390} height={560}>
        <ScrollFrame mobile><Dashboard count="empty" /></ScrollFrame>
      </DCArtboard>
    </DCSection>

    <DCSection id="lookup" title="03 · Guest order lookup (/order-lookup/)">
      <DCArtboard id="lk-form-d" label="Desktop · form" width={1280} height={720}>
        <ScrollFrame><GuestLookup state="form" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="lk-error-d" label="Desktop · error (generic)" width={1280} height={780}>
        <ScrollFrame><GuestLookup state="error-generic" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="lk-rate-d" label="Desktop · rate-limited" width={1280} height={720}>
        <ScrollFrame><GuestLookup state="error-rate" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="lk-results-d" label="Desktop · results" width={1280} height={1240}>
        <ScrollFrame><GuestLookup state="results" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="lk-form-m" label="Mobile · form" width={390} height={780}>
        <ScrollFrame mobile><GuestLookup state="form" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="lk-error-m" label="Mobile · error" width={390} height={840}>
        <ScrollFrame mobile><GuestLookup state="error-generic" /></ScrollFrame>
      </DCArtboard>

      <DCArtboard id="lk-results-m" label="Mobile · results" width={390} height={1500}>
        <ScrollFrame mobile><GuestLookup state="results" /></ScrollFrame>
      </DCArtboard>
    </DCSection>

    <DCSection id="notes" title="04 · Style note">
      <DCArtboard id="note" label="Tokens & rationale" width={920} height={1280}>
        <StyleNote />
      </DCArtboard>
    </DCSection>
  </DesignCanvas>
);

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
