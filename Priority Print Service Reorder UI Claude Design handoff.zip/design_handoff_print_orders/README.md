# Handoff: Priority Print — Print Orders & Guest Lookup

## Overview
Two customer-facing pages on a WooCommerce store at priorityprintservice.com:

1. **Logged-in dashboard** at `My Account → Print Orders` — a new sibling tab to WooCommerce's default account endpoints. Lists every PPS print order the customer has placed, newest first, paginated.
2. **Guest order lookup** at `/order-lookup/` — a standalone WordPress page (rendered via shortcode) where unauthenticated buyers verify with order # + billing email + order date, then see all print orders associated with that billing email.

Both pages share a per-line-item **Order Card** component.

## About the design files
The HTML/JSX bundled here are **design references**, not production code. They were built as a pan/zoom canvas of artboards purely to communicate visual intent and behavior. Your job is to **recreate these designs in the live WordPress/WooCommerce theme** using the conventions already in that codebase (PHP templates, the theme's enqueued CSS, server-rendered markup) — not to ship the React/JSX as-is.

Specifically:
- The dashboard endpoint is a WooCommerce custom endpoint. The markup belongs in `myaccount/print-orders.php` (or equivalent template).
- The guest lookup is a shortcode-rendered page; markup belongs in the shortcode handler.
- Forms post back to themselves (no JS gating). JS may enhance (e.g., copy-to-clipboard on order #) but never gate.
- No React. No build step expected. Translate the JSX-shaped components into PHP partials.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, and interactions are settled. Recreate pixel-faithfully against these tokens. The only flagged additions to the brand token set are listed under **Design Tokens → New tokens** below.

---

## Design Tokens

### Color
All values are literal — do not introduce new accents.

| Token | Hex | Use |
|---|---|---|
| `process-cyan` | `#007eff` | Primary actions, links, product titles (h4) |
| `process-cyan-light` | `#e0edff` | "Processing" pill bg |
| `process-cyan-dark` | `#0062c4` | Primary button hover/focus bg |
| `process-magenta` | `#d1246a` | Rush emphasis, required-field marker, lookup eyebrow |
| `process-magenta-light` | `#fce8ef` | "Rush" pill bg |
| `process-yellow` | `#f0a830` | Warnings, "Printing" status accent |
| `process-yellow-light` | `#fef5e0` | "Printing" pill bg, flag chip |
| `key` | `#2b2b2b` | Body text, headings |
| `mid` | `#555` | Secondary text, sidebar default |
| `light` | `#999` | Tertiary / metadata, disabled pager |
| `bg` | `#f4f4f4` | Page surface |
| `card-bg` | `#f0faff` | Order-card bg (PPS-era) |
| `card-border` | `#b8e0f5` | Order-card border |
| `border` | `#d8d8d8` | Inputs, dividers, default card border |
| `error` | `#c25050` | Error text, input border on error |
| `success-light` | `#f0fad6` | Reserved (rare) |

### New tokens introduced — please flag
| Token | Value | Rationale |
|---|---|---|
| `error-bg` | `#fbeded` | Background for the generic error banner. Derived from `--error` at ~10% over white. |
| `pill-shipped` (bg / fg) | `#e6f3e0` / `#4a7a2c` | Status pill for "Shipped". Sits between yellow (printing) and grey (delivered) without inventing a new accent. |
| `pill-delivered` (bg / fg) | `#e8e8e8` / `#555` | Neutral grey for completed orders so the eye lands on active jobs. |

### Typography
- Family: `'Segoe UI', sans-serif` (matches calculator)
- Body: 14px / 1.5
- Secondary: 13px / 1.5
- h4 / card title: 16px / 600, color `process-cyan`
- Page heading: 26px / 700, letter-spacing -0.01em
- Pill / badge: 10–11px uppercase, letter-spacing 0.5px, weight 700
- Spec block: SF Mono / Menlo / Consolas, 12.5px, line-height 1.55

### Shape
- Card radius: 6px
- Input radius: 4px
- Pill radius: 10px
- Card elevation: **none** — 1px border only, no drop shadows
- Button transitions: 120ms bg/border-color/color shift only — no lift, scale, or shadow

### Focus & accessibility
- All interactive elements visibly focusable.
- Focus ring on inputs: `border-color: var(--process-cyan); box-shadow: 0 0 0 3px rgba(0,126,255,0.18);`
- Focus ring on primary button: `outline: 3px solid rgba(0,126,255,0.32); outline-offset: 1px;`
- Color contrast ≥ 4.5:1 for all text/bg pairs.
- Error banners use `role="alert"`.
- Inputs use `<label htmlFor="...">` tied to id.

---

## Screens

### A. Order Card (shared component)

**Layout (desktop ≥ 640px):** CSS grid, three columns: `140px 1fr auto`, gap 20px, padding 18px, radius 6px, 1px border.

**Layout (mobile < 640px):** two columns `96px 1fr` for thumb + body; actions wrap to a third row spanning full width, button stretches.

**Sub-elements:**
- **Thumbnail** — 140×140 (96×96 mobile), white bg, 1px border `--border`, radius 4px, `object-fit: cover`. Resize, never crop. **If absent (legacy orders), leave the column blank — no placeholder graphic.**
- **Title** — `<a>`, 16px, 600, color `--process-cyan`, underline on hover.
- **Meta line** — 13px `--mid`. Order #, date, status pill, optionally rush pill. Separator: middle dot `·` in `--light`.
- **Status pill** — see token table above. 10px uppercase, 0.5px letter-spacing, 3px 9px padding, 10px radius.
- **ETA line** — 13px, `--key`, "Estimated delivery: **Friday, May 2, 2026**". Bold the date.
- **Spec block** — `<pre>`, mono, 12.5px, color `--mid`, padded 10px 12px, bg `rgba(255,255,255,0.6)` over the cyan card so it reads as a sub-surface, radius 4px. Multi-line, preserve newlines, `white-space: pre-wrap`.
- **Actions** — vertical stack, right-aligned. Primary button + small "View details ↗" link below.

**States:**

1. **Standard (PPS-era)** — bg `--card-bg`, border `--card-border`. Has thumbnail, mono spec block, **Reorder** button. Reorder → product page with calculator pre-filled (GET link).
2. **Legacy** — bg `--white`, border `--border`. No thumbnail (column left empty, NOT a placeholder graphic). Spec block uses sans `--font-ui` 13px on `--bg` instead of mono — reads as a one-line summary. Button label: **Reorder (same as before)**. Below the button: 11px `--light` caveat: "Specs can't be changed — [contact us](mailto:…) for edits." Reorder → drops item directly into cart, redirects to `/cart/`.
3. **Cancelled / refunded** — same chrome as legacy, but `opacity: 0.65`, ETA line replaced with refund note ("Refunded on …"), Reorder button replaced with disabled ghost button "Reorder unavailable" (no cursor, faded).
4. **Hover on Reorder** — bg shifts to `--process-cyan-dark` (`#0062c4`).
5. **Keyboard focus on Reorder** — bg `--process-cyan-dark` plus `outline: 3px solid rgba(0,126,255,0.32); outline-offset: 1px;`.

### B. Print Orders dashboard (logged in)

**Page chrome:** the site's existing header/footer. The body sits inside WooCommerce's My Account shell.

**Sidebar (left):** WooCommerce's default account menu — Dashboard, Orders, **Print Orders** (active), Addresses, Payment Methods, Account Details, Logout. **Use whatever WooCommerce + the active theme already render for this menu — do not restyle it specifically for our tab.** The mock shows a generic representation only so you can see the relationship; in production the real theme menu wins. Active state for our tab: 3px left border in `--process-cyan`, bg `--bg`, weight 600.

**Content (right):**
- Heading "Your Print Orders" — 26px / 700.
- Sub-line "Re-order the same job, grab a proof, or check delivery." — 13px `--mid`.
- List of order cards, newest first, **10 per page**.
- Pager: split-justified row above a top border. Left: "← Previous" (or grey disabled). Center: "Page N of M · K orders". Right: "Next →".

**States:**
- **Many items** — typical view (mock shows 4 cards mixing standard, shipped, legacy, refunded).
- **One item** — single card, pager shows "Page 1 of 1" with both arrows disabled.
- **Empty state** — 36px vertical padding, single 14px `--mid` line "No print orders yet." with a primary button "Browse calculators" pushed to the right via `margin-left: auto`. Deliberately near-invisible — no illustration.

**Mobile layout:** sidebar collapses to a full-width column above the content (or use the theme's existing mobile account-nav pattern). All padding tightens to 16px. Cards stack at 360px+ legibly.

### C. Guest order lookup (`/order-lookup/`)

**Page chrome:** site header (with "Sign in" link instead of account dropdown) + footer. Theme padding wraps the body.

**Form state:**
- Centered shell, max-width 480px.
- Eyebrow "GUEST ORDER LOOKUP" — 10px / 700 / 0.12em letter-spacing, color `--process-magenta`.
- H1 "Find your print orders" — 24px / 700.
- Form card: white, 1px `--border`, radius 6px, padding 24px.
- Intro: "Enter your order details to view your print orders. **All three fields must match.**" (13px `--mid`, "All three" bolded in `--key`)
- Three stacked fields: Order number (text, `inputMode="numeric"`), Billing email (email), Order date (native `<input type="date">`).
- Each field: 12px / 600 label, magenta `*` on required, input 9×11px padding, 4px radius, 1px `--border`.
- Honeypot: `<input class="honeypot" tabindex="-1" autocomplete="off" name="hp_company">` positioned `left: -9999px`.
- WordPress nonce hidden field next to it.
- Submit: full-width primary button "View my orders".
- Foot: 12px `--light` centered: "Have an account? [Sign in](#) for the full dashboard."

**Error states:**
- **Generic mismatch** — banner above form: bg `--error-bg`, 1px `#e8c5c5`, alert-circle SVG icon, **"We couldn't find a matching order."** plus a 12px sub-line "Double-check the order number, billing email, and order date." All three inputs get `border-color: var(--error)`. **Never indicate which field was wrong.**
- **Rate-limited** (after 5 failed attempts in 15 min) — same banner styling, copy: **"Too many attempts."** sub: "Please try again in 15 minutes, or [contact support](#)." Inputs do NOT show the red border in this case.

**Authenticated/results state:**
- Wider shell, max-width 760px (room for cards).
- Auth strip: white card, 1px `--border`, padding 12×16, flex row. Left: "Showing orders for **marcia@firstchurch.org**" (email bold, `--key`). Right: ghost button "Sign out of lookup" (transparent bg, 1px `--border`, padding 6×12, 12px).
- Below: same Order Card component, up to 20 cards.
- Footer note (12px `--light`, centered): "Want to edit a pending order? [Sign in to your account.](#)"
- Session lasts 30 minutes server-side; **no expiry warning UI** — when session expires, posting the form again returns to the form state.

---

## Interactions & Behavior

| Action | Result |
|---|---|
| Click product title (PPS-era card) | Navigate to product page (no calculator pre-fill — that's the Reorder button's job). |
| Click **Reorder** (PPS-era) | GET link → product page with React calculator pre-filled from this order's specs. |
| Click **Reorder (same as before)** (legacy) | GET link → adds item directly to cart with original price preserved → redirect to `/cart/`. |
| Click **View details ↗** | Native WC order detail page (`/my-account/view-order/{id}/`). |
| Click pager arrow | Reload with `?paged=N`. Disabled state when at boundary — render as `<span>`, not `<a>`. |
| Submit guest lookup form | POST to self. Server validates nonce, checks honeypot empty, matches order #/email/date. On success, set 30-min session cookie, render results state. On failure, render error state + increment rate-limit counter. |
| Click **Sign out of lookup** | POST to self with `action=lookup_logout` → clears session cookie → renders form state. |
| Hover Reorder | Bg `--process-cyan-dark`, 120ms transition. |
| Keyboard-focus Reorder | Bg `--process-cyan-dark` + cyan outline ring. |
| Tab order | Logical: header → sidebar → page content top-to-bottom → footer. Skip-links if the theme provides them. |

### Privacy / security
- Dashboard never shows billing address, phone, or payment method.
- Guest lookup never differentiates "wrong email" vs "wrong date" — same generic error every time.
- Rate-limit applies per IP+email combination, 5 attempts / 15 min.

### Responsive
- Breakpoint at 640px (or align with the theme's existing breakpoint).
- Cards stack and remain legible at 360px wide.
- Thumbnail resizes (140 → 96), never crops (`object-fit: cover` is fine because aspect is 1:1 in both cases).
- Action button stretches full width on mobile.

---

## State Management
Server-rendered; no client state required for core flows. Optional JS enhancements:
- Copy-to-clipboard on order # (progressive enhancement, never gates).
- Date-picker polyfill if you need to support a browser without `<input type="date">` (most don't).
- `aria-live` polite region around the pager if you decide to load pages via XHR (out of scope by default).

---

## Assets
- **Thumbnails** — provided per-order by the backend (artwork upload from the original order). Render as `<img>` with `loading="lazy"` and `alt=""` (decorative — title carries the meaning).
- **Icons** — only one inline SVG: the alert circle in the error banner. No icon font, no emoji.
- **No logos or brand marks beyond what the existing site header already carries.**

---

## Files included in this bundle

| File | Role |
|---|---|
| `Print Orders Account UI.html` | Top-level canvas. Open in a browser to see all artboards. Pan/zoom + click an artboard to focus. |
| `styles.css` | Design tokens + every CSS rule referenced in the markup. The CSS values here are the source of truth for measurements, colors, and states — port them to whatever stylesheet your theme uses. |
| `order-card.jsx` | OrderCard component — translate to a PHP partial taking the same props (variant, product, orderNo, date, status, rush, eta, thumb, specs). |
| `screens.jsx` | Dashboard + GuestLookup screen compositions (header, sidebar, form, results, error banners). |
| `style-note.jsx` | The style-note artboard contents — same info as this README rendered visually. |
| `canvas-app.jsx` | Wires artboards onto the design canvas. **Ignore for production** — purely a presentation harness. |
| `design-canvas.jsx` | The pan/zoom canvas component itself. **Ignore for production.** |

The two files you'll spend most time mapping to PHP are `order-card.jsx` and `screens.jsx`; `styles.css` is the visual contract.

## Out of scope (deliberately)
Notifications, proof-approval UI, per-set artwork upload, custom order statuses, internationalization, dark mode.
