/* Style-note artboard */

const StyleNote = () => {
  const tokens = [
    ["process-cyan",        "#007eff", "Primary actions, links, product titles"],
    ["process-cyan-light",  "#e0edff", "Status pill bg (Processing), subtle highlights"],
    ["process-magenta",     "#d1246a", "Rush emphasis, required-field markers, eyebrow"],
    ["process-magenta-light","#fce8ef","Rush badge bg"],
    ["process-yellow",      "#f0a830", "Warnings, Printing-status accent"],
    ["process-yellow-light","#fef5e0", "Printing pill bg, flag chip"],
    ["key",      "#2b2b2b", "Body text, headings"],
    ["mid",      "#555555", "Secondary text, sidebar default"],
    ["light",    "#999999", "Tertiary / metadata, disabled pager"],
    ["bg",       "#f4f4f4", "Page surface"],
    ["card-bg",  "#f0faff", "Order-card background (PPS-era)"],
    ["card-border","#b8e0f5","Order-card border"],
    ["border",   "#d8d8d8", "Inputs, dividers, default card"],
    ["error",    "#c25050", "Error text & input borders"],
    ["success-light","#f0fad6","Reserved for rare success states"],
  ];
  const newTokens = [
    ["error-bg",  "#fbeded", "Background for the generic error banner. Derived from existing --error at ~10% opacity over white."],
    ["pill-shipped (bg / fg)", "#e6f3e0 / #4a7a2c", "Status pill for ‘Shipped’. Reads as ‘in motion, on its way’ without inventing a new accent — sits between yellow (printing) and grey (delivered)."],
    ["pill-delivered (bg / fg)", "#e8e8e8 / #555", "Neutral grey for completed orders so the eye lands on active jobs first."],
  ];

  return (
    <div className="notes">
      <h2>Style note</h2>
      <p>One-page reference for the Print Orders pages. All values follow the brief's CMYK token system; three derived neutrals are flagged below.</p>

      <h3>Color tokens in use</h3>
      <div className="swatch-grid">
        {tokens.map(([name, hex, use]) => (
          <div key={name} className="swatch">
            <div className="sw-color" style={{ background: hex }} />
            <div className="sw-meta">
              <span className="name">{name}</span>
              <span className="hex">{hex}</span>
              <div style={{ marginTop: 4, color: "var(--mid)" }}>{use}</div>
            </div>
          </div>
        ))}
      </div>

      <h3>New tokens introduced <span className="flag">flag</span></h3>
      <table className="token-table">
        <thead>
          <tr><th>Token</th><th>Value</th><th>Rationale</th></tr>
        </thead>
        <tbody>
          {newTokens.map(([name, val, why]) => (
            <tr key={name}>
              <td className="mono">{name}</td>
              <td className="mono">{val}</td>
              <td>{why}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Type</h3>
      <table className="token-table">
        <tbody>
          <tr><td>Family</td><td className="mono">'Segoe UI', sans-serif</td><td>Per brief; matches calculator.</td></tr>
          <tr><td>Body</td><td className="mono">14 / 1.5</td><td>Card content, list items.</td></tr>
          <tr><td>Secondary</td><td className="mono">13 / 1.5</td><td>Meta, helper text.</td></tr>
          <tr><td>h4 / card title</td><td className="mono">16 / 600</td><td>Product names, in process-cyan.</td></tr>
          <tr><td>Page heading</td><td className="mono">26 / 700</td><td>“Your Print Orders”, lookup title.</td></tr>
          <tr><td>Pill / badge</td><td className="mono">10–11 uppercase, 0.5 letter-spacing</td><td>Status, rush, eyebrow.</td></tr>
          <tr><td>Spec block</td><td className="mono">SF Mono / Menlo, 12.5</td><td>Treats specs as a job ticket — light print-shop nod without going heavy.</td></tr>
        </tbody>
      </table>

      <h3>Shape & motion</h3>
      <table className="token-table">
        <tbody>
          <tr><td>Card radius</td><td className="mono">6px</td><td>Per brief.</td></tr>
          <tr><td>Input radius</td><td className="mono">4px</td><td>Per brief.</td></tr>
          <tr><td>Pill radius</td><td className="mono">10px</td><td>Per brief.</td></tr>
          <tr><td>Card elevation</td><td className="mono">none</td><td>1px border only — no drop shadows, per brief.</td></tr>
          <tr><td>Button hover</td><td className="mono">bg shift only, 120ms</td><td>No lift / scale, no shadow.</td></tr>
          <tr><td>Focus ring</td><td className="mono">3px rgba(0,126,255,0.18–0.32)</td><td>Cyan-derived; meets 3:1 contrast against page bg.</td></tr>
        </tbody>
      </table>

      <h3>Iconography</h3>
      <p>Inline SVG only (banner alert, pager arrows). No emoji. No decorative print marks (registration, color bars) — kept to colors only per the chosen direction.</p>
    </div>
  );
};

window.StyleNote = StyleNote;
