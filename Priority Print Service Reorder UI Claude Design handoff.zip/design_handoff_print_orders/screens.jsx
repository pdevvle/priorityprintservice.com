/* Shared chrome + screens */

const SiteHeader = () => (
  <header className="pps-header">
    <div className="brand">
      <span className="cmyk-dots"><i/><i/><i/><i/></span>
      <span>PRIORITY PRINT</span>
    </div>
    <nav className="nav desktop-only">
      <a href="#">Booklets</a>
      <a href="#">Brochures</a>
      <a href="#">Coupon Books</a>
      <a href="#">Calculators</a>
      <a href="#" className="active">My Account</a>
    </nav>
    <div style={{ fontSize: 12, color: "var(--mid)" }}>
      Hi, <strong style={{ color: "var(--key)" }}>Marcia</strong> · <a href="#" style={{ color: "var(--mid)" }}>Logout</a>
    </div>
  </header>
);

const SiteHeaderGuest = () => (
  <header className="pps-header">
    <div className="brand">
      <span className="cmyk-dots"><i/><i/><i/><i/></span>
      <span>PRIORITY PRINT</span>
    </div>
    <nav className="nav desktop-only">
      <a href="#">Booklets</a>
      <a href="#">Brochures</a>
      <a href="#">Coupon Books</a>
      <a href="#">Calculators</a>
      <a href="#">Sign in</a>
    </nav>
  </header>
);

const SiteFooter = () => (
  <footer className="pps-footer">
    <span>© 2026 Priority Print Service · Phoenix, AZ</span>
    <span>(602) 555-0144 · help@priorityprintservice.com</span>
  </footer>
);

const WCSidebar = ({ active = "print-orders" }) => {
  const items = [
    ["dashboard", "Dashboard"],
    ["orders", "Orders"],
    ["print-orders", "Print Orders"],
    ["addresses", "Addresses"],
    ["payment", "Payment Methods"],
    ["account", "Account Details"],
    ["logout", "Logout"],
  ];
  return (
    <aside className="wc-sidebar">
      {items.map(([k, label]) => (
        <a key={k} href="#" className={k === active ? "active" : ""}>{label}</a>
      ))}
    </aside>
  );
};

/* ====================================================
   Dashboard — full screen
==================================================== */
const Dashboard = ({ count = "many" }) => {
  return (
    <div className="pps">
      <SiteHeader />
      <main className="pps-page">
        <div className="wc-account">
          <WCSidebar />
          <section className="wc-content">
            <h1 className="h-page">Your Print Orders</h1>
            <p className="h-sub">Re-order the same job, grab a proof, or check delivery.</p>

            {count === "empty" && (
              <div className="empty">
                <span>No print orders yet.</span>
                <a href="#" className="btn btn-primary">Browse calculators</a>
              </div>
            )}

            {count === "one" && (
              <>
                <OrderCard
                  product="Coupon Book — Tear-Off"
                  orderNo="2188"
                  date="Apr 22, 2026"
                  status={{ label: "Printing", kind: "printing" }}
                  rush={true}
                  eta="Tuesday, Apr 28, 2026"
                  thumb="coupon"
                  specs={"5.5 × 8.5 in · 250 sets · 50 pp\n4/0 color, 70# offset text\nPerforated tear-line\nRush production: 2-day"}
                />
                <div className="pager">
                  <span className="disabled">← Previous</span>
                  <span>Page 1 of 1</span>
                  <span className="disabled">Next →</span>
                </div>
              </>
            )}

            {count === "many" && (
              <>
                <OrderCard
                  product="Saddle-Stitched Booklet"
                  orderNo="2204"
                  date="Apr 24, 2026"
                  status={{ label: "Processing", kind: "processing" }}
                  eta="Friday, May 2, 2026"
                  thumb="booklet"
                  specs={"8.5 × 11 in · 100 sets · 24 pp\n4/4 color, 100# gloss text\nCover: 100# gloss cover, AQ\nSaddle-stitched · 2 staples"}
                />
                <OrderCard
                  product="Tri-Fold Brochure"
                  orderNo="2188"
                  date="Apr 22, 2026"
                  status={{ label: "Shipped", kind: "shipped" }}
                  eta="Wednesday, Apr 29, 2026"
                  thumb="brochure"
                  specs={"8.5 × 11 in flat → 3.67 × 8.5 folded · 500 sets\n4/4 color, 100# gloss text\nScored & tri-folded"}
                />
                <OrderCard
                  variant="legacy"
                  product="Perfect-Bound Catalog"
                  orderNo="0941"
                  date="Sep 03, 2024"
                  status={{ label: "Delivered", kind: "delivered" }}
                  eta=""
                  specs={"8.5 × 11 · 64 pp · 250 sets · 4/4 · perfect bound · 80# gloss"}
                />
                <OrderCard
                  variant="cancelled"
                  product="Saddle-Stitched Booklet"
                  orderNo="2076"
                  date="Apr 11, 2026"
                  status={{ label: "Refunded", kind: "refunded" }}
                  eta=""
                  thumb="booklet"
                  specs={"6 × 9 in · 50 sets · 16 pp\n4/4 color, 80# matte text"}
                />
                <div className="pager">
                  <span className="disabled">← Previous</span>
                  <span>Page 1 of 3 · 24 orders</span>
                  <a href="#">Next →</a>
                </div>
              </>
            )}
          </section>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
};

/* ====================================================
   Guest Lookup
==================================================== */
const GuestLookup = ({ state = "form" }) => {
  return (
    <div className="pps">
      <SiteHeaderGuest />
      <main className="pps-page">
        {state !== "results" ? (
          <div className="lookup-shell">
            <p className="lookup-eyebrow">Guest order lookup</p>
            <h1 className="lookup-title">Find your print orders</h1>

            <form className="form" noValidate>
              {state === "error-generic" && (
                <div className="banner banner-error" role="alert">
                  <svg className="banner-icon" viewBox="0 0 16 16" fill="none">
                    <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="1.5"/>
                    <path d="M8 4v5M8 11.5v.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  </svg>
                  <div>
                    <strong>We couldn&rsquo;t find a matching order.</strong>
                    <div style={{ fontSize: 12, marginTop: 2, color: "var(--mid)" }}>
                      Double-check the order number, billing email, and order date.
                    </div>
                  </div>
                </div>
              )}
              {state === "error-rate" && (
                <div className="banner banner-error" role="alert">
                  <svg className="banner-icon" viewBox="0 0 16 16" fill="none">
                    <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="1.5"/>
                    <path d="M8 4v5M8 11.5v.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  </svg>
                  <div>
                    <strong>Too many attempts.</strong>
                    <div style={{ fontSize: 12, marginTop: 2, color: "var(--mid)" }}>
                      Please try again in 15 minutes, or <a href="#" style={{ color: "var(--process-cyan)" }}>contact support</a>.
                    </div>
                  </div>
                </div>
              )}

              <p className="form-intro">
                Enter your order details to view your print orders. <strong style={{ color: "var(--key)" }}>All three fields must match.</strong>
              </p>

              <div className={`field ${state === "error-generic" ? "has-error" : ""}`}>
                <label htmlFor="g-order">Order number <span className="req">*</span></label>
                <input id="g-order" type="text" inputMode="numeric" defaultValue={state === "error-generic" ? "2188" : ""} placeholder="e.g. 2204"/>
              </div>

              <div className={`field ${state === "error-generic" ? "has-error" : ""}`}>
                <label htmlFor="g-email">Billing email <span className="req">*</span></label>
                <input id="g-email" type="email" defaultValue={state === "error-generic" ? "marcia@firstchurch.org" : ""} placeholder="you@example.com"/>
              </div>

              <div className={`field ${state === "error-generic" ? "has-error" : ""}`}>
                <label htmlFor="g-date">Order date <span className="req">*</span></label>
                <input id="g-date" type="date" defaultValue={state === "error-generic" ? "2026-04-21" : ""}/>
                <span className="field-hint">The date the order was placed.</span>
              </div>

              {/* Honeypot — visually hidden */}
              <input className="honeypot" tabIndex="-1" autoComplete="off" name="hp_company" />

              <button type="submit" className="btn btn-primary btn-submit">View my orders</button>

              <p className="form-foot">
                Have an account? <a href="#">Sign in</a> for the full dashboard.
              </p>
            </form>
          </div>
        ) : (
          /* Results state */
          <div style={{ maxWidth: 760, margin: "0 auto" }}>
            <div className="auth-strip">
              <div>Showing orders for <strong>marcia@firstchurch.org</strong></div>
              <button className="btn btn-ghost" style={{ padding: "6px 12px", fontSize: 12 }}>Sign out of lookup</button>
            </div>

            <OrderCard
              product="Coupon Book — Tear-Off"
              orderNo="2188"
              date="Apr 22, 2026"
              status={{ label: "Printing", kind: "printing" }}
              rush={true}
              eta="Tuesday, Apr 28, 2026"
              thumb="coupon"
              specs={"5.5 × 8.5 in · 250 sets · 50 pp\n4/0 color, 70# offset text\nPerforated tear-line\nRush production: 2-day"}
            />
            <OrderCard
              product="Saddle-Stitched Booklet"
              orderNo="2076"
              date="Apr 11, 2026"
              status={{ label: "Delivered", kind: "delivered" }}
              eta="Apr 18, 2026"
              thumb="booklet"
              specs={"8.5 × 11 in · 100 sets · 24 pp\n4/4 color, 100# gloss text"}
            />
            <OrderCard
              variant="legacy"
              product="Perfect-Bound Program"
              orderNo="0941"
              date="Sep 03, 2024"
              status={{ label: "Delivered", kind: "delivered" }}
              eta=""
              specs={"8.5 × 11 · 64 pp · 250 sets · 4/4 · perfect bound"}
            />

            <p className="results-foot">
              Want to edit a pending order? <a href="#" style={{ color: "var(--process-cyan)" }}>Sign in to your account.</a>
            </p>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
};

window.SiteHeader = SiteHeader;
window.SiteHeaderGuest = SiteHeaderGuest;
window.SiteFooter = SiteFooter;
window.WCSidebar = WCSidebar;
window.Dashboard = Dashboard;
window.GuestLookup = GuestLookup;
