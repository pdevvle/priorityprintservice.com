/* OrderCard — shared component, all 4 states. */

const Pill = ({ kind, children }) => (
  <span className={`pill pill-${kind}`}>{children}</span>
);

const PLACEHOLDER_THUMBS = {
  booklet: (
    <svg viewBox="0 0 140 140" width="140" height="140">
      <rect width="140" height="140" fill="#fafafa"/>
      <rect x="34" y="22" width="72" height="96" fill="#ffffff" stroke="#d8d8d8" strokeWidth="1"/>
      <rect x="34" y="22" width="2" height="96" fill="#b8e0f5"/>
      <rect x="44" y="38" width="52" height="6" fill="#2b2b2b"/>
      <rect x="44" y="50" width="40" height="3" fill="#999"/>
      <rect x="44" y="58" width="44" height="3" fill="#999"/>
      <rect x="44" y="66" width="36" height="3" fill="#999"/>
      <rect x="44" y="86" width="52" height="20" fill="#e0edff"/>
      <rect x="48" y="92" width="20" height="3" fill="#007eff"/>
      <rect x="48" y="98" width="32" height="3" fill="#007eff"/>
    </svg>
  ),
  brochure: (
    <svg viewBox="0 0 140 140" width="140" height="140">
      <rect width="140" height="140" fill="#fafafa"/>
      <g transform="translate(14,30)">
        <rect width="36" height="80" fill="#fff" stroke="#d8d8d8"/>
        <rect x="36" width="36" height="80" fill="#fff" stroke="#d8d8d8"/>
        <rect x="72" width="36" height="80" fill="#fff" stroke="#d8d8d8"/>
        <rect x="6" y="10" width="24" height="3" fill="#d1246a"/>
        <rect x="6" y="18" width="18" height="2" fill="#999"/>
        <rect x="42" y="14" width="24" height="14" fill="#f0a830"/>
        <rect x="42" y="34" width="24" height="2" fill="#999"/>
        <rect x="42" y="40" width="20" height="2" fill="#999"/>
        <rect x="78" y="10" width="24" height="3" fill="#007eff"/>
        <rect x="78" y="18" width="18" height="2" fill="#999"/>
        <rect x="78" y="26" width="22" height="2" fill="#999"/>
      </g>
    </svg>
  ),
  coupon: (
    <svg viewBox="0 0 140 140" width="140" height="140">
      <rect width="140" height="140" fill="#fafafa"/>
      <rect x="20" y="34" width="100" height="72" fill="#fff" stroke="#d8d8d8"/>
      <line x1="20" y1="58" x2="120" y2="58" stroke="#d8d8d8" strokeDasharray="3 3"/>
      <line x1="20" y1="82" x2="120" y2="82" stroke="#d8d8d8" strokeDasharray="3 3"/>
      <rect x="28" y="42" width="40" height="3" fill="#2b2b2b"/>
      <rect x="28" y="48" width="28" height="2" fill="#999"/>
      <rect x="92" y="42" width="22" height="10" fill="#d1246a"/>
      <rect x="28" y="66" width="40" height="3" fill="#2b2b2b"/>
      <rect x="28" y="72" width="28" height="2" fill="#999"/>
      <rect x="92" y="66" width="22" height="10" fill="#007eff"/>
      <rect x="28" y="90" width="40" height="3" fill="#2b2b2b"/>
      <rect x="28" y="96" width="28" height="2" fill="#999"/>
      <rect x="92" y="90" width="22" height="10" fill="#f0a830"/>
    </svg>
  ),
};

const OrderCard = ({
  variant = "standard",            // standard | legacy | cancelled | hover-demo | focus-demo
  product = "Saddle-Stitched Booklet",
  orderNo = "1234",
  date = "Apr 12, 2026",
  status = { label: "Processing", kind: "processing" },
  rush = false,
  eta = "Friday, May 2, 2026",
  thumb = "booklet",
  specs = "8.5 × 11 in · 100 sets · 24 pp\n4/4 color, 100# gloss text\nCover: 100# gloss cover, AQ\nSaddle-stitched · 2 staples",
}) => {
  const isLegacy    = variant === "legacy";
  const isCancelled = variant === "cancelled";
  const isHoverDemo = variant === "hover-demo";
  const isFocusDemo = variant === "focus-demo";

  return (
    <article className={`order-card ${isLegacy ? "legacy" : ""} ${isCancelled ? "cancelled" : ""}`}>
      {/* Thumb column */}
      {isLegacy ? (
        <div className="oc-thumb-empty" aria-hidden="true" />
      ) : (
        <div className="oc-thumb">{PLACEHOLDER_THUMBS[thumb] || PLACEHOLDER_THUMBS.booklet}</div>
      )}

      {/* Body */}
      <div className="oc-body">
        <a href="#" className="oc-title">{product}</a>
        <div className="oc-meta">
          <span>Order #{orderNo}</span>
          <span className="dot">·</span>
          <span>{date}</span>
          <span className="dot">·</span>
          <Pill kind={status.kind}>{status.label}</Pill>
          {rush && <Pill kind="rush">Rush</Pill>}
        </div>
        {!isCancelled && eta && (
          <div className="oc-eta">Estimated delivery: <strong>{eta}</strong></div>
        )}
        {isCancelled && (
          <div className="oc-eta" style={{ color: "var(--mid)" }}>
            Refunded on Apr 14, 2026 · No further action needed.
          </div>
        )}
        <pre className="oc-specs">{specs}</pre>
      </div>

      {/* Actions */}
      <div className="oc-actions">
        {isCancelled ? (
          <button className="btn btn-ghost" disabled style={{ opacity: 0.6, cursor: "not-allowed" }}>
            Reorder unavailable
          </button>
        ) : isLegacy ? (
          <>
            <a href="#"
               className={`btn btn-primary ${isHoverDemo ? "is-hover" : ""} ${isFocusDemo ? "is-focus" : ""}`}>
              Reorder (same as before)
            </a>
            <p className="oc-caveat">
              Specs can&rsquo;t be changed — <a href="#" style={{ color: "var(--process-cyan)" }}>contact us</a> for edits.
            </p>
          </>
        ) : (
          <a href="#"
             className={`btn btn-primary ${isHoverDemo ? "is-hover" : ""} ${isFocusDemo ? "is-focus" : ""}`}>
            Reorder
          </a>
        )}
        {!isCancelled && !isLegacy && (
          <a href="#" className="btn-link" style={{ fontSize: 12, fontWeight: 500 }}>
            View details ↗
          </a>
        )}
      </div>
    </article>
  );
};

window.OrderCard = OrderCard;
window.Pill = Pill;
